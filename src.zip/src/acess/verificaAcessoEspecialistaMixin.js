export default {
    beforeMount() {
      let usuario = JSON.parse(localStorage.getItem('usu'));
  
      if (usuario.tipo !== 'Gestor' && usuario.tipo !== 'Especialista') {
        alert('Você não tem acesso a esta página');
        this.$router.push("chat");
      }
    }
  };  