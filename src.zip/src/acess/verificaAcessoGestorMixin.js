export default {
  beforeMount() {
    let usuario = JSON.parse(localStorage.getItem('usu'));

    if (usuario.tipo !== 'Gestor') {
      alert('Você não tem acesso a esta página');
        this.$router.push("dashboard");
      }   
  }
};  