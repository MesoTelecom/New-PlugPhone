<template>

  <v-container class="fill-height" fluid>
    <v-card-text class="mt-12" id="centralizado">

      <!--text--accent-NUMBER altera a cor da letra do texto-->
      <h1 class="text-center display-1">Seja bem-vindo ao PlugPhone Cloud</h1>
      <!--div que trata botões de Facebook, Google e Linkedin-->

      <v-form style="width: 53%;     margin-left: 23%;">
        <v-text-field label="Digite seu usuário" name="usuario" type="text" color="#61a5e8" v-model="usuario"
          prepend-icon="email" />

        <v-text-field id="password" label="Digite sua senha" name="senha" type="password" color="#61a5e8"
          v-model="senha" prepend-icon="lock" />

      </v-form>
    </v-card-text>
    <div class="text-center" style="width: 100%">
      <v-btn rounded @click="login" color="#61a5e8" class="centralizado" style="color: white;">Login</v-btn>



    </div>
  </v-container>


</template>

<script>
import { api } from "@/conf/api";



export default {
  name: "HomeView",
  data: () => ({
    usuario: "",
    senha: "",
    error: false,
  }),
  methods: {

    async login() {
      try {
        //localStorage.removeItem( "jwt");

        this.error = false;
        let res = await api.post("loginconfere/", {
          login: this.usuario+"-Meso",
          senha: this.senha,
        });
        if (res.data && res.data.token) {
          //console.log('res',res.data.token)
          this.$store.state.token = res.data.token;
          this.$store.state.logado = res.data.tipo;
          this.$store.state.adm = res.data.tipo == "admin";
          let usu = {
            usuario: this.usuario,
            pin: res.data.token,
            tipo: res.data.tipo,
            grupo: res.data.grupo,
          };
          this.$store.dispatch('insereUsuario', usu)
          localStorage.setItem("usu", JSON.stringify(usu));
          localStorage.setItem("jwt", this.$store.state.token);

          api.defaults.headers.common[
            "x-access-token"
          ] = this.$store.state.token;

          if (res.data.tipo == "Técnico" || res.data.tipo == 'Comercial' || res.data.tipo == 'Financeiro') {
            this.$router.push("dashboard");
          }
        } else {
          this.error = true;
        }
        if (res.data.tipo == "vendedor") {
          localStorage.setItem("jwt", this.$store.state.token);
          api.defaults.headers.common[
            "x-access-token"
          ] = this.$store.state.token;

          this.$router.push("estoque");

        }
        //// console.log(res.data.dados[0]);
      } catch (e) {
        //// console.log("err", e);
      }
    },
  },
  mounted() {
    this.$store.state.logado = false;
    this.$store.state.adm = false;
  },
};
</script>

<style scoped>
#centralizado {
  margin-left: 3% !important;
  margin-top: 14% !important;
}

h1 {

  color: #595E71;
}

#fill-height {

  background-color: #243e57;
}

.v-text-field {

  width: 50%;
  margin-left: 24%;
}

.v-btn {

  margin-left: 0%;

}

.text-center {

  color: #595E71;
  position: center;
}

.text-center1 {

  color: #595E71;
  position: center;
  background-color: transparent;
}


.cardanna {

  /* background-image: url(../assets/modelo.jpg);*/
  background-repeat: no-repeat;
  background-size: 0%;



}

.col-md-4 {
  color: transparent;
}

.v-btn__content {

  position: center;
}


.show-enter-active,
.show-leave-enter {
  transform: translateX(0);
  transition: all .3s linear;
}

.show-enter,
.show-leave-to {
  transform: translateX(100%);
}

.fill-height {




  background-repeat: no-repeat;
  background-size: 100%;

  box-shadow: inset 0 0 0 1000px rgb(205 205 205 / 52%);
  background-image: url(../assets/mesofundo.jpg);
  padding: 15px;
  background-repeat: no-repeat;
  background-size: cover;
  background-position: center;


}

.text-center:hover,
.col-md-4:hover {

  background-color: transparent;


}
</style>
